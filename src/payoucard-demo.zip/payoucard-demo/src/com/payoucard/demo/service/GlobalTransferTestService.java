package com.payoucard.demo.service;

import cn.hutool.json.JSONUtil;
import cn.hutool.log.Log;
import cn.hutool.log.LogFactory;
import com.payoucard.demo.utils.CommonUtil;
import com.payoucard.demo.utils.PayouCardUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: piero
 * @date: 2024/03/25 17:03
 * @describe: Global Money Transfer Test API
 */
public class GlobalTransferTestService {

    private static final Log log = LogFactory.get();

    /**
     * server url
     */
    private static final String SERVER_URL = "https://api-merchant-test.logtec.me";

    /**
     * PayouCard public key
     */
    private static final String PAYOUCARD_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCe2TsRV2zgejEiByyzXItEuyBjaw/K6fjma3SyeGCfAL0bfN4nCBjkNptxDb+PuNl6/uxyrw5wn437k1VByce+7PXvUYfZw4jqqjE/8xej4jwF48Wedw17KcKFfmWpRWTftI04tFLIEMrjU4jPlu17IEez/bsiePS3l3ZJ4jI34QIDAQAB";

    /**
     * Merchant ID
     */
    private static final String MERCHANT_ID = "88888888";

    /**
     * Merchant public key
     */
    private static final String MERCHANT_PUBLIC_KEY = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCZ9zvGgSFugE1QDGUE4rlJVAyQXZH9srAuCwRnsO6tqD0EBjYzxl87+910Q8zSD/MjrG1HyWQ45GARRj5QFZtoSySX5U2L+zC2rkj5NoryST99S3vqFmCuoFb0+JEd5qRZ9ZAvegUfoTTIYT0CqtwTgd0ydZsz+8W1p3rmbfMEFwIDAQAB";

    /**
     * Merchant private key
     */
    private static final String MERCHANT_PRIVATE_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAJn3O8aBIW6ATVAMZQTiuUlUDJBdkf2ysC4LBGew7q2oPQQGNjPGXzv73XRDzNIP8yOsbUfJZDjkYBFGPlAVm2hLJJflTYv7MLauSPk2ivJJP31Le+oWYK6gVvT4kR3mpFn1kC96BR+hNMhhPQKq3BOB3TJ1mzP7xbWneuZt8wQXAgMBAAECgYA7sN4711Rewt82aZfAjSXIiA1W6u/uq5giQaMzkCT4roD5Tm81I3NIjh0NNjvyNLzO18qGSk3QwLl9+P2vjrDw5CIqHozkWOq+fiK6IhCJJaBgrxf3JuBvsQvcef03cRMPw4u+v5wNkkXPtLefk3p8XbQomMKFinzqEXxbm4I6AQJBAM5zYZHrvi5flJcy8spoiIhZ3pzK1JhTySqew8+Zl5RrdNaDmQh2dbQJFam0W9mFtn2MMQALmme+dAqaa+MOTfsCQQC+6xqXLjAUPd/nraO20/PY+3sPfcGs4sEsQMLVhi4oM7pVlUUUbkoGH7+rNUNmrUGwpMVb+lZiWekgCUs6ohOVAkEAr0u7OirAhiG0SpoBG6qc26Hrapiy4VCrTBwYyYpx8Z04TPjalRv4n1DjawBwyQdHR90kshQoHBTT9TjfiKDZxwJAeGNsWxSnALybqk4WRD2XMKYzzWrxbAF46lzT/y0jgfpMb5c2/lEloIL4rA9kNyTdnXPpd7x+KHqlxKvXolt9mQJAaJNHF0et5SLDRESs3iRFBsS3caVt/1GrIg0iRgX33bnA4/uX77h9He3J63t3qEFP8XN9BZlEATxo1wcZJ6twLg==";





    public static void main(String[] args) throws Exception {
//        getExchangeRate();
//        queryBankConfig();
//        getOrderResult();
//        fileUpload();
//        payment();
//        submitTransferOrderInfo();
    }

    /**
     * Query legal currency exchange rate
     *
     * @return
     * @throws Exception
     */
    public static void getExchangeRate() throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("currency", "EUR");
        data.put("targetCurrency", "SGD");
        data.put("targetCountry", "SG");
        log.debug("requestData:{}", JSONUtil.toJsonPrettyStr(data));

        String requestStr = PayouCardUtil.initCommonRequest(data, MERCHANT_ID, MERCHANT_PRIVATE_KEY);
        log.debug("requestStr:{}", JSONUtil.toJsonPrettyStr(requestStr));

        String path = "/order/merchant/globalTransfer/getExchangeRate";
        String body = CommonUtil.postJson(SERVER_URL + path, requestStr);
        log.debug("responseStr:{}", JSONUtil.toJsonPrettyStr(body));

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Boolean success = (Boolean) responseMap.get(PayouCardUtil.SUCCESS);
        if (success) {
            boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
            log.debug("verify signature result:{}", flag);
        }

    }

    /**
     * Query global remittance countries, banks and related configurations
     *
     * @return
     * @throws Exception
     */
    public static void queryBankConfig() throws Exception {
        String requestStr = PayouCardUtil.initCommonRequest(null, MERCHANT_ID, MERCHANT_PRIVATE_KEY);
        log.debug("requestStr:{}", requestStr);

        String path = "/order/merchant/globalTransfer/queryBankConfig";
        String body = CommonUtil.postJson(SERVER_URL + path, requestStr);
        log.debug("responseStr:{}", body);

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Boolean success = (Boolean) responseMap.get(PayouCardUtil.SUCCESS);
        if (success) {
            boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
            log.debug("verify signature result:{}", flag);
        }
    }

    /**
     * Query order results
     *
     * @return
     * @throws Exception
     */
    public static void getOrderResult() throws Exception {
        Map<String, Object> data = new HashMap<>(1);
        data.put("orderNo", 1234567890L);

        String requestStr = PayouCardUtil.initCommonRequest(data, MERCHANT_ID, MERCHANT_PRIVATE_KEY);
        log.debug("requestStr:{}", requestStr);

        String path = "/order/merchant/globalTransfer/getOrderResult";
        String body = CommonUtil.postJson(SERVER_URL + path, requestStr);
        log.debug("responseStr:{}", body);

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Boolean success = (Boolean) responseMap.get(PayouCardUtil.SUCCESS);
        if (success) {
            boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
            log.debug("verify signature result:{}", flag);
        }
    }


    /**
     * 查询订单结果
     *
     * @return
     * @throws Exception
     */
    public static void fileUpload() throws Exception {
        String requestStr = PayouCardUtil.initCommonRequest(null, MERCHANT_ID, MERCHANT_PRIVATE_KEY);

        Map<String, Object> paramMap = JSONUtil.toBean(requestStr, Map.class);
        log.debug("requestStr:{}", requestStr);

        File file = new File("src/resource/test.png");
        String path = "/order/merchant/file/upload";
        String body = CommonUtil.postFormData(SERVER_URL + path, file, paramMap);
        log.debug("responseStr:{}", body);

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Boolean success = (Boolean) responseMap.get(PayouCardUtil.SUCCESS);
        if (success) {
            boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
            log.debug("verify signature result:{}", flag);
        }
    }

    /**
     * Submit order information
     *
     * @return
     * @throws Exception
     */
    public static void submitTransferOrderInfo() throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("orderNo", 1234567890L);

        Map<String, Object> transferInfos1 = new HashMap<>();
        transferInfos1.put("code", 1);
        transferInfos1.put("content", "tom");

        Map<String, Object> transferInfos2 = new HashMap<>();
        transferInfos2.put("code", 16);
        transferInfos2.put("content", "2002-10-10");
        List<Map<String, Object>> transferInfos = new ArrayList<>();
        transferInfos.add(transferInfos1);
        transferInfos.add(transferInfos2);
        data.put("transferInfos", transferInfos);

        Map<String, Object> transferFiles1 = new HashMap<>();
        transferFiles1.put("code", 26);
        transferFiles1.put("content", "https://d2xgu4h8kg06u1.cloudfront.net/s3-mcc-test/merchant/88888888/2024-04-24/e5f197f5-14ef-4174-8df7-b93640d88217_123.png");
        Map<String, Object> transferFiles2 = new HashMap<>();
        transferFiles2.put("code", 27);
        transferFiles2.put("content", "https://d2xgu4h8kg06u1.cloudfront.net/s3-mcc-test/merchant/88888888/2024-04-24/e5f197f5-14ef-4174-8df7-b93640d88217_123.png");
        List<Map<String, Object>> transferFiles = new ArrayList<>();
        transferFiles.add(transferFiles1);
        transferFiles.add(transferFiles2);
        data.put("transferFiles", transferFiles);


        String requestStr = PayouCardUtil.initCommonRequest(data, MERCHANT_ID, MERCHANT_PRIVATE_KEY);
        log.debug("requestStr:{}", requestStr);

        String path = "/order/merchant/globalTransfer/submitTransferOrderInfo";
        String body = CommonUtil.postJson(SERVER_URL + path, requestStr);
        log.debug("responseStr:{}", body);

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Boolean success = (Boolean) responseMap.get(PayouCardUtil.SUCCESS);
        if (success) {
        boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
        log.debug("verify signature result:{}", flag);
        }
    }




    /**
     * 查询订单结果
     *
     * @return
     * @throws Exception
     */
    public static void payment() throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("uniqueId", "654321");
        data.put("originOrderNo", "6232agf2g342fd123457");
        data.put("amount", 110);
        data.put("postscript", "testy");
        data.put("relationship", "OTHER");
        data.put("sourceFunds", "SAVINGS");
        data.put("payPurpose", "PURCHASE_OF_GOODS_OR_SERVICES");
        data.put("bankId", 3541);

        Map<String, Object> payer = new HashMap<>();
        payer.put("payerType", "INDIVIDUAL");
        payer.put("payerLastName", "william");
        payer.put("payerFirstName", "wang piero");
        payer.put("payerIdNo", "BB123456");
        payer.put("payerIdNoType", "PASSPORT");
        payer.put("payerIdCountry", "CN");
        payer.put("payerBirthday", "2000-01-01");
        payer.put("payerNationalityCountry", "CN");
        payer.put("payerMobile", "+13900001111");
        payer.put("payerCountryCode", "CN");
        payer.put("payerCityCode", "CN_11_1");
        payer.put("payerAddress", "bei");
        payer.put("payerPostCode", "111111");
        payer.put("payerOccupation", "worker");
        data.put("payer", payer);

        Map<String, Object> payee = new HashMap<>();
        payee.put("benAccountNum", "19801011011");
        payee.put("benAccountName", "test t");
        payee.put("benLastName", "t");
        payee.put("benFirstName", "test1");
        payee.put("benMobileCode", "+86");
        payee.put("benMobile", "19899998888");
        data.put("payee", payee);


        String requestStr = PayouCardUtil.initCommonRequest(data, MERCHANT_ID, MERCHANT_PRIVATE_KEY);

        String path = "/order/merchant/globalTransfer/payment";
        String body = CommonUtil.postJson(SERVER_URL + path, requestStr);
        log.debug("responseStr:{}", body);

        Map<String, Object> responseMap = JSONUtil.toBean(body, Map.class);
        Integer code = (Integer) responseMap.get(PayouCardUtil.CODE);
        if (code == 0) {
            boolean flag = PayouCardUtil.verifySignature(body, PAYOUCARD_PUBLIC_KEY);
            log.debug("verify signature result:{}", flag);
        }
    }


}
