package com.payoucard.demo.utils;

import cn.hutool.core.util.StrUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.json.JSONUtil;
import cn.hutool.log.Log;
import cn.hutool.log.LogFactory;

import java.io.File;
import java.util.Map;

/**
 * @author: piero
 * @date: 2024/03/25 17:03
 * @describe:
 */
public class CommonUtil {

    private static final Log logger = LogFactory.get();

    /**
     * post json
     *
     * @param url
     * @param paramStr
     * @return
     */
    public static String postJson(String url, String paramStr) {
        long startTime = System.currentTimeMillis();
        cn.hutool.http.HttpResponse response = null;
        try {
            response = HttpRequest.post(url).body(paramStr).execute();
            logger.info("sendPostJson url {}, param {}. result: code {}, ret: {}, cost: {}", url,
                    getExeFileString(paramStr), response.getStatus(), response.body(), System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            logger.error("sendPostForm exception", e);
        }
        return response.body();
    }


    /**
     * post json
     *
     * @param url
     * @param file
     * @param paramMap
     * @return
     */
    public static String postFormData(String url, File file, Map<String, Object> paramMap) {
        long startTime = System.currentTimeMillis();
        cn.hutool.http.HttpResponse response = null;
        try {
            response = HttpRequest.post(url)
                    .form("file", file)
                    .form(paramMap)
                    .execute();
            logger.info("sendPostJson url {}, param {}. result: code {}, ret: {}, cost: {}", url,
                    getExeFileString(JSONUtil.toJsonStr(paramMap)), response.getStatus(), response.body(), System.currentTimeMillis() - startTime);
        } catch (Exception e) {
            logger.error("exception", e);
        }
        return response.body();
    }

    private static String getExeFileString(String param) {
        if (StrUtil.isNotBlank(param)) {
            return param.replaceAll("(\"[a-zA-Z]*template\":)(\"[^\"]+\")", "#");
        }
        return param;
    }


}
