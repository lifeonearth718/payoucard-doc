package com.payoucard.demo.utils;

import cn.hutool.json.JSONUtil;
import cn.hutool.log.Log;
import cn.hutool.log.LogFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * @Author: piero
 * @date: 2024/3/31 15:01
 * @describe:
 */
public class PayouCardUtil {

    public static final String SUCCESS = "success";
    public static final String CODE = "code";

    public static final String MESSAGE = "message";

    public static final String DATA = "data";

    /**
     * signature string
     */
    public static final String SIGNATURE = "signature";
    public static final String REQUEST_ID = "requestId";

    /**
     * Merchant ID
     */
    public static final String MERCHANT_ID = "merchantId";

    /**
     * callback notification type
     */
    public static final String NOTIFY_TYPE = "notifyType";

    /**
     * requestId prefix
     */
    public static final String PYC = "PYC";

    private static final Log log = LogFactory.get();

    /**
     * Initialize request template parameters
     *
     * @param data business data. Can be empty
     * @param merchantId Merchant ID
     * @param privateKey private key
     * @return
     * @throws Exception
     */
    public static String initCommonRequest(Object data, String merchantId, String privateKey) throws Exception {
        Map<String, Object> commonParamMap = buildCommonParam(null, null, null, data, null, merchantId);
        String signDataStr = getTreeValue(commonParamMap);
        log.info("signDataStr:{}", signDataStr);

        commonParamMap.put("signature", RsaUtils.signSHA256(signDataStr.getBytes(StandardCharsets.UTF_8), privateKey));
        String commonParamStr = JSONUtil.toJsonStr(commonParamMap);
        log.debug("commonRequest:{}", commonParamStr);
        return commonParamStr;
    }


    /**
     * Verify signature
     *
     * @param responseStr response string
     * @param publicKey public key
     * @return
     * @throws Exception
     */
    public static boolean verifySignature(String responseStr, String publicKey) throws Exception {
        Map<String, Object> requestMap = JSONUtil.toBean(responseStr, Map.class);
        String signature = String.valueOf(requestMap.get(SIGNATURE));
        requestMap.remove(SIGNATURE);

        //验证 signature
        String signDataStr = getTreeValue(requestMap);
        log.info("verify signDataStr:{}", signDataStr);
        return RsaUtils.verify(signDataStr.getBytes(StandardCharsets.UTF_8), publicKey, signature);
    }

    /**
     * Generate request ID
     * @param prefix
     * @return String
     */
    public static String genRequestId(String prefix) {
        return StringUtils.isNotBlank(prefix) ? prefix : PYC +
                DateFormatUtils.format(new Date(), "yyyyMMddHHmmssSSS");
    }

    /**
     * Construct signature string
     *
     * @param paramMap
     * @return
     */
    private static String getTreeValue(Map<String, Object> paramMap) {
        TreeMap<String, Object> params = new TreeMap<>(paramMap);
        StringBuilder origin = new StringBuilder();
        for (String key : params.keySet()) {
            Object value = params.get(key);
            String valueStr = String.valueOf(value);
            //空值参数不参与签名
            if (Objects.nonNull(value) && !JSONUtil.isNull(value) && StringUtils.isNotBlank(valueStr)) {
                origin.append("&").append(key).append("=").append(valueStr);
            }
        }
        return origin.substring(1);
    }


    private static Map<String, Object> buildCommonParam(Object code, Object success, Object message, Object data, Integer notifyType, String merchantId) {
        Map<String, Object> commonParamMap = new HashMap<>();
        commonParamMap.put(REQUEST_ID, genRequestId(null));
        commonParamMap.put(MERCHANT_ID, merchantId);
        commonParamMap.put(NOTIFY_TYPE, notifyType);
        commonParamMap.put(CODE, code);
        commonParamMap.put(SUCCESS, success);
        commonParamMap.put(MESSAGE, message);
        commonParamMap.put(DATA, data);
        if (Objects.nonNull(data)) {
            if (JSONUtil.isTypeJSONObject(String.valueOf(data))) {
                commonParamMap.put(DATA, JSONUtil.parseObj(data));
            } else if (JSONUtil.isTypeJSONArray(String.valueOf(data))) {
                commonParamMap.put(DATA, JSONUtil.parseArray(data));
            }
        }
        return commonParamMap;
    }

}